﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RabbitMQ.Client;

namespace RabbitMQ.Publish
{
    public class HelloWorldWithRouting
    {
        public static void Run()
        {
            ConnectionFactory factory = new ConnectionFactory { HostName = "192.168.11.80" };
            using (IConnection connection = factory.CreateConnection())
            {
                using (IModel channel = connection.CreateModel())
                {
                    channel.QueueDeclare("HelloWorldWithRouting", false, false, false, null);
                    while (true)
                    {
                        Console.WriteLine("Please enter routing key: ");
                        var routingKey = Console.ReadLine() ?? "info";
                        Console.WriteLine("Please enter message: ");
                        var message = Console.ReadLine() ?? "";
                        channel.BasicPublish("", routingKey, null, Encoding.UTF8.GetBytes(message));
                    }
                }
            }
        }
    }
}
