﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RabbitMQ.Client;

namespace RabbitMQ.Publish
{
    public class Topic
    {
        public static void Run()
        {
            ConnectionFactory factory = new ConnectionFactory { HostName = "192.168.11.80" };
            using (IConnection connection = factory.CreateConnection())
            {
                using (IModel channel = connection.CreateModel())
                {
                    channel.ExchangeDeclare("Topic", "topic");
                    while (true)
                    {
                        Console.WriteLine("Please enter topic: ");
                        var topic = Console.ReadLine() ?? "";
                        Console.WriteLine("Please enter message: ");
                        var message = Console.ReadLine() ?? "hello world.";
                        channel.BasicPublish("Topic", topic, null, Encoding.UTF8.GetBytes(message));
                    }
                }
            }
        }
    }
}
