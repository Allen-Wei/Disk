﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RabbitMQ.Client;

namespace RabbitMQ.Publish
{
    public class PublishSubscribe
    {
        public static void Run()
        {
            ConnectionFactory factory = new ConnectionFactory { HostName = "192.168.11.80" };
            using (IConnection connection = factory.CreateConnection())
            {
                using (IModel channel = connection.CreateModel())
                {
                    channel.ExchangeDeclare("PublishSubscribe", "fanout");
                    while (true)
                    {
                        Console.WriteLine("Please enter message: ");
                        var message = Console.ReadLine() ?? "";
                        channel.BasicPublish("PublishSubscribe", "", null, Encoding.UTF8.GetBytes(message));
                    }
                }
            }
        }
    }
}
