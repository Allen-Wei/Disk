﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;

namespace RabbitMQ.Subscribe
{
    public class HelloWorld
    {
        public static void Run()
        {
 
            ConnectionFactory factory = new ConnectionFactory { HostName = "192.168.11.80" };
            using (IConnection connection = factory.CreateConnection())
            {
                using (IModel channel = connection.CreateModel())
                {
                    channel.QueueDeclare("helloworld", false, false, false, null);
                    var consumer = new EventingBasicConsumer(channel);
                    consumer.Received += (model, ea) =>
                    {
                        Console.WriteLine(Encoding.UTF8.GetString(ea.Body));
                    };
                    channel.BasicConsume(queue: "helloworld", noAck: true, consumer: consumer);
                    Console.ReadLine();
                }
            }

        }
    }
}
