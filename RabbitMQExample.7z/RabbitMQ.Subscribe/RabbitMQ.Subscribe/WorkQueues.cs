﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;

namespace RabbitMQ.Subscribe
{
    public class WorkQueues
    {
        public static void Run()
        {
            ConnectionFactory factory = new ConnectionFactory() { HostName = "192.168.11.80" };
            using (IConnection connection = factory.CreateConnection())
            {
                using (IModel channel = connection.CreateModel())
                {
                    var q = "WorkQueues";
                    channel.QueueDeclare(q, true, false, false, null);
                    EventingBasicConsumer consumer = new EventingBasicConsumer(channel);
                    consumer.Received += (model, ea) =>
                    {
                        var message = Encoding.UTF8.GetString(ea.Body);
                        Console.Write(message + " ");
                        var dotLength = message.Split('.').Length - 1;
                        Thread.Sleep(dotLength * 1000);
                        Console.WriteLine("done");
                        //channel.BasicAck(ea.DeliveryTag, false);
                    };
                    channel.BasicConsume(q, true, consumer);
                    Console.ReadLine();
                }
            }
        }
    }
}
