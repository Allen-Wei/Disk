﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;

namespace RabbitMQ.Subscribe
{
    public class Routing
    {
        public static void Run()
        {
            ConnectionFactory factory = new ConnectionFactory { HostName = "192.168.11.80" };
            using (IConnection connection = factory.CreateConnection())
            {
                using (IModel channel = connection.CreateModel())
                {
                    //channel.ExchangeDeclare("Routing", "direct");
                    Console.WriteLine("Please enter routing key: ");
                    var routingKeys = (Console.ReadLine() ?? "info").Split(' ').ToList();
                    var queueName = channel.QueueDeclare().QueueName;

                    routingKeys.ForEach(k =>
                    {
                        channel.QueueBind(queueName, "Routing", k);
                    });

                    EventingBasicConsumer consumer = new EventingBasicConsumer(channel);
                    consumer.Received += (model, ea) =>
                    {
                        var message = Encoding.UTF8.GetString(ea.Body);
                        Console.WriteLine("Routing Key: {0}, Message: {1}", ea.RoutingKey, message);
                    };
                    channel.BasicConsume(queueName, true, consumer);

                    Console.ReadLine();
                }
            }
        }

    }
}
