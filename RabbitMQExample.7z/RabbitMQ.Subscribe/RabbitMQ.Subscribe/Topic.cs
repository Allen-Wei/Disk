﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;

namespace RabbitMQ.Subscribe
{
    public class Topic
    {
        public static void Run()
        {
            ConnectionFactory factory = new ConnectionFactory { HostName = "192.168.11.80" };
            using (IConnection connection = factory.CreateConnection())
            {
                using (IModel channel = connection.CreateModel())
                {
                    var queueName = channel.QueueDeclare().QueueName;
                    Console.WriteLine("Please enter topics: ");
                    (Console.ReadLine() ?? "").Split(' ').ToList().ForEach(topic =>
                    {
                        channel.QueueBind(queueName, "Topic", topic);
                    });
                    EventingBasicConsumer consumer = new EventingBasicConsumer(channel);
                    consumer.Received += (model, ea) =>
                    {
                        var message = Encoding.UTF8.GetString(ea.Body);
                        Console.WriteLine(message);
                    };
                    channel.BasicConsume(queueName, true, consumer);

                    Console.ReadLine();
                }
            }
        }
    }
}
